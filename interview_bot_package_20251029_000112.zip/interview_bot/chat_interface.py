import json
import os
from interview_bot import InterviewBot
from datetime import datetime

class ChatBot:
    def __init__(self):
        self.bot = InterviewBot()
        self.context = {}
        self.conversation_history = []
        
    def save_conversation(self):
        """Save conversation history to a file"""
        if not os.path.exists('chat_history'):
            os.makedirs('chat_history')
            
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'chat_history/conversation_{timestamp}.json'
        
        with open(filename, 'w') as f:
            json.dump(self.conversation_history, f, indent=2)
            
    def process_message(self, message):
        """Process user message and return response"""
        message = message.lower().strip()
        
        # Add user message to history
        self.conversation_history.append({
            "role": "user",
            "message": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Initial greeting
        if any(greeting in message for greeting in ['hi', 'hello', 'hey']):
            response = (
                "Hello! I'm your Interview Preparation Assistant. I can help you with:\n"
                "1. Finding interview questions for specific companies\n"
                "2. Questions by experience level\n"
                "3. Questions by category (like Selenium, API Testing, etc.)\n"
                "4. Questions by difficulty level\n\n"
                "What would you like to know about?"
            )
            
        # Company specific questions
        elif "questions" in message and any(company.lower() in message for company in self.bot.get_available_companies()):
            company = next(c for c in self.bot.get_available_companies() if c.lower() in message.lower())
            
            # Try to extract experience from message
            experience = "2"  # default
            for word in message.split():
                if word.replace('.', '').isdigit():
                    experience = word
                    break
                    
            response = self.bot.format_response(
                self.bot.get_interview_questions(company, experience)
            )
            
        # Show categories
        elif "categories" in message or "topics" in message:
            categories = self.bot.get_categories()
            response = "Here are the available categories and their topics:\n\n"
            for category, topics in categories.items():
                response += f"{category}:\n"
                for topic in topics:
                    response += f"  - {topic}\n"
                    
        # Show companies
        elif "companies" in message:
            companies = self.bot.get_available_companies()
            response = "Here are the companies I have questions for:\n\n"
            response += "\n".join(f"- {company}" for company in companies)
            
        # Help message
        elif "help" in message:
            response = (
                "Here's how you can interact with me:\n\n"
                "- Ask for questions: 'Show me TCS interview questions for 2 years experience'\n"
                "- View categories: 'What categories of questions do you have?'\n"
                "- List companies: 'Which companies do you have questions for?'\n"
                "- Get specific: 'Show me Selenium questions for Microsoft'\n"
                "- Filter by difficulty: 'Show me advanced questions for Amazon'\n\n"
                "You can also combine these: 'Show me advanced Selenium questions for TCS with 3 years experience'"
            )
            
        # Goodbye
        elif any(word in message for word in ['bye', 'goodbye', 'exit', 'quit']):
            self.save_conversation()
            response = "Thank you for using the Interview Bot! Your conversation has been saved. Good luck with your interview preparation!"
            
        # Default response
        else:
            response = (
                "I'm not sure I understood that. You can:\n"
                "- Ask for company specific questions\n"
                "- View question categories\n"
                "- List available companies\n"
                "- Type 'help' for more details\n"
            )
            
        # Add bot response to history
        self.conversation_history.append({
            "role": "bot",
            "message": response,
            "timestamp": datetime.now().isoformat()
        })
        
        return response

def main():
    chat_bot = ChatBot()
    print("Welcome to the Interview Preparation Chat Bot!")
    print("Type 'help' for guidance or 'exit' to quit.")
    print("=" * 60)
    
    while True:
        try:
            user_input = input("\nYou: ").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ['exit', 'quit', 'bye', 'goodbye']:
                response = chat_bot.process_message(user_input)
                print(f"\nBot: {response}")
                break
                
            response = chat_bot.process_message(user_input)
            print(f"\nBot: {response}")
            
        except KeyboardInterrupt:
            print("\n\nExiting gracefully...")
            chat_bot.save_conversation()
            break
        except Exception as e:
            print(f"\nBot: I encountered an error: {str(e)}")
            print("Let's try something else!")

if __name__ == "__main__":
    main()